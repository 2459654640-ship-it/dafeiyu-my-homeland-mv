请先阅读 v3/README.md。
完整渲染命令：python v3/source/render.py --parallel-master
