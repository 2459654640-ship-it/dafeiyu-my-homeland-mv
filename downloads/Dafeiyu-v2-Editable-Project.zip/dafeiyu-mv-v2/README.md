请先阅读 v2/README.md。
完整渲染命令：python v2/source/film.py
