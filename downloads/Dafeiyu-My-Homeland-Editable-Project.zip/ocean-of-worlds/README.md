# 大肥鱼我的家乡

独立的二次元科幻音乐 MV 工程，位于 `/workspace/ocean-of-worlds`。与 `/workspace/dead-freight-prototype` 游戏工程没有代码、素材或运行依赖关系。

## 成片与审片

- `output/大肥鱼我的家乡_1080p.mp4`：完整 195 秒，原生 1920×1080 / 30 fps，H.264 / AAC，BT.709。
- `output/大肥鱼我的家乡_双语字幕.srt`：可编辑的英文／中文时间轴。
- `output/镜头总览.jpg`：分镜抽样，不替代动态审片。
- `output/review.html`：打开本地成片、按章节跳转的审片页。
- `output/cover.jpg`：片头角色与正式片名的封面。

开场第一次出现人物即为双手合在胸前的抱拳／问候造型。正式片名固定为「大肥鱼我的家乡」。本片没有上传或发布到 B 站。

## 创作结构

她向观众问好。一个人写下名字，终端中的微光开始生长。界面的命令成为海面、轨道与星鲸；角色也能够成为字符构成的三维存在。人类与她的指尖相遇，递归空间里诞生新的世界。结尾回到相同的问候姿态，含义已经由「你好」变为「欢迎回家」。

不是把歌曲波形画成一张图：镜头按歌词与编曲段落编排，节拍改变轨道形变与曝光，低频改变海面位移，镜头间以字符网格解码转场。片中界面为原创的 Harness 风格虚构交互，不连接真实模型，不执行画面里的工具调用。

实现包含：角色透明卡片的网格形变、匹配的闭眼／睁眼关键帧、三维波浪等值线、参数化星鲸、环面流线、递归门廊、三阶 Menger 几何、球面轨道群、角色三维字符点云、四分之一分辨率辉光、有限的色差与颗粒。人物表演为关键帧美术和 2.5D 合成，并非完整三维角色骨骼动画；海面与流线为解析程序动画，并非高成本流体物理仿真。

## 复现

需要 Linux、Python 3.12、FFmpeg、Mesa EGL / OpenGL 3.3+、Noto CJK 与 DejaVu Sans Mono 字体。当前机器已具备这些依赖。工作区和缓存应可写，保留继承的 HTTPS 代理和 TLS 校验设置。

```bash
cd /workspace/ocean-of-worlds
python3 -m venv .venv
.venv/bin/pip install -r requirements-render.txt
.venv/bin/python source/render.py
```

`analysis/features.npz`、`analysis/music.json`、`analysis/lyrics.json` 是已保存的音频特征与对齐结果，普通改画面不需要重新下载模型或重新跑音频分析。绘制角色的六张生成美术保存在 `assets/`。每个图像资源的来源见 `docs/SOURCES.md`。

快速检查指定镜头或渲染片段：

```bash
.venv/bin/python source/render.py --stills --width 1280 --height 720 --times 2.7,17.3,65,100,145,168
.venv/bin/python source/render.py --start 59 --duration 21 --output output/chorus-review.mp4
```

默认完整输出需要渲染 5,850 帧。在本机软件渲染器上约为 10 fps，速度取决于镜头与 CPU 资源。不是实时视频生成服务，也没有额外 API 消费。

## 修改路径

- 改镜头顺序／起止时间：`source/render.py` 的 `storyboard()`。
- 改角色出现的位置／景别／运动：`Renderer.render()`。
- 改会话、运行日志、片头片尾：`Renderer.overlay()`。
- 改几何：`source/geometry.py`。
- 改着色、转场、辉光：`source/*.vert`、`source/*.frag`。
- 改字幕与翻译：`analysis/lyrics.json`，并重新运行 `source/package.py` 更新 SRT。

工程支持随机访问任意时刻，随机数种子固定。修改一个镜头不需要重新生成所有美术。不要在播放量承诺、完整三维人物动画或实际模型内部机制方面误读这些画面。

## 音频对齐的证据边界

音频由用户提供，最终使用原音轨；分离出来的人声只用于分析。先用 HDEMUCS_HIGH_MUSDB_PLUS 分离人声，再用 Wav2Vec2_ASR_BASE_960H 取得 CTC 音素分布。初次对整首混音的自动对齐在高音和长间奏处失败，不能使用；`source/align.py` 在分离人声上加入歌词段落边界，避免跨越间奏。

最终字幕为 16 行。模型时间网格是 20 ms，这不等于人工确认的 20 ms 准确度。已检查时间顺序、段落边界和抽样画面；人声拖腔的细微词尾仍适合最终听审。审片页可直接跳到两段副歌。没有把静态抽样检查描述成整片逐帧、逐词的人耳验收。

## 参考与署名

参考 MisakaZentai《world.execute(me);》的「界面行为成为叙事」与「每一帧由歌曲时间决定」的方法。研究了仓库公开预览、制作说明、镜头转场、字幕和合成代码；当前网络无法直接读取 B 站视频页面，未宣称完整观看原片。本片没有复制该仓库的镜头或导入其渲染模块。

角色设计：上善（鲸鱼娘原作）、ZipZipPipe（女仆二次设计）。用户提供角色参考；本片角色美术由 AI 依据参考生成。相关上游角色美术的署名链与 CC BY-NC-SA 4.0 说明保留在 `references/character-NOTICE.txt` 与 `docs/SOURCES.md`。参考仓库中另含 Mili 音乐与 MMD 的说明，那些音乐、模型和动作没有用于本片。

发布说明应准确写明含 AI 生成角色美术及原创程序渲染、属于非官方同人。音乐与角色的适用权利并不因工程源码可见而变更。
